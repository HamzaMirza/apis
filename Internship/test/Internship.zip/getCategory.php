<?php require_once("config.php");?>
<?php 
		
		$connection=$_SESSION["CONNECTION"];
		$response = array();
		$t_id=test_input(mysqli_real_escape_string($_SESSION["CONNECTION"],$_POST['t_id']) );
		$result = mysqli_query($connection,"SELECT category.Category_ID as id,Category_NAME FROM Category join product on category.category_ID = product.category_ID join type on product.T_ID=type.t_ID where type.t_ID=".$t_id."") or die(mysqli_error());
		if (mysqli_num_rows($result) > 0) 
		{
			$response["clothes"] = array();
			while ($row = mysqli_fetch_array($result)) 
			{
				$clothes = array();
				$clothes["T_ID"] = $row["id"];
				$clothes["T_NAME"] = $row["Category_NAME"];
				array_push($response["clothes"], $clothes);
			}

		} 
		else 
		{
			$response["success"] = 0;
			$response["message"] = "No item in the cart";
		}
		
		
			    echo json_encode($response);
		
		
		function test_input($data)
		{
			$data = trim($data);
			$data = stripslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}
		

               
	

				
?>