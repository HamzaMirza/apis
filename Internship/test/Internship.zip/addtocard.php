<?php require_once("config.php");?>
<?php 
		
		$connection=$_SESSION["CONNECTION"];
		
		//Saving data in variables.
		$pro_id=test_input(mysqli_real_escape_string($_SESSION["CONNECTION"],$_POST['pro_id']) );
		$size=test_input(mysqli_real_escape_string($_SESSION["CONNECTION"],$_POST['size']) );
		$color=test_input(mysqli_real_escape_string($_SESSION["CONNECTION"],$_POST['color']) );
		$quantity=test_input(mysqli_real_escape_string($_SESSION["CONNECTION"],$_POST['quantity']) );
		$price=test_input(mysqli_real_escape_string($_SESSION["CONNECTION"],$_POST['price']) );
		$type=test_input(mysqli_real_escape_string($_SESSION["CONNECTION"],$_POST['type']) );
		$total=$quantity * $price;

		
		function test_input($data)
		{
			$data = trim($data);
			$data = stripslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}
		//Adding to the card

		$response = array();
		$response["success"] = 0;
		$response["session_id"]=$_SESSION["sess_id"];
		$response["pro_id"] = $pro_id;
		$response["size"] = $size;
		$response["color"] = $color;
		$response["price"] = $price;
		$response["quantity"]=$quantity;
		$response["total"] = $total;
		$response["type"] = $type;
		
 $Query="INSERT INTO `cart`(`SessionID`, `pro_id`, `size`, `color`, `price`, `Quantity`, `total`, `ip`,`t_id`)VALUES (".$_SESSION["sess_id"].",".$pro_id.",'".$size."','".$color."',".$price.",".$quantity.",".$total.",'".$_SESSION["ipAddress"]."',".$type.")";
					 if(($Result=mysqli_query($connection,$Query)))
					 {
						 $response["success"] = 1;
					 }
		//db mey card ka table and config wali file mey session id banani hai
		echo json_encode($response);
               
	

				
?>