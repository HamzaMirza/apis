<?php require_once("config.php");?>
<?php 
		
		$connection=$_SESSION["CONNECTION"];
		$response = array();
		$result = mysqli_query($connection,"SELECT store_id,store_name,store_latitude FROM storeslocation") or die(mysqli_error());
		if (mysqli_num_rows($result) > 0) 
		{
			$response["clothes"] = array();
			while ($row = mysqli_fetch_array($result)) 
			{
				$clothes = array();
				$clothes["store_id"] = $row["store_id"];
				$clothes["store_name"] = $row["store_name"];
				$clothes["store_latitude"] = $row["store_latitude"];
				array_push($response["clothes"], $clothes);
			}

		} 
		else 
		{
			$response["success"] = 0;
			$response["message"] = "No item in the cart";
		}
		
		
			    echo json_encode($response);
		
		
		function test_input($data)
		{
			$data = trim($data);
			$data = stripslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}
		

               
	

				
?>