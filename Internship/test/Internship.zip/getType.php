<?php require_once("config.php");?>
<?php 
		
		$connection=$_SESSION["CONNECTION"];

		$response = array();

		$result = mysqli_query($connection,"SELECT T_ID,T_NAME FROM TYPE") or die(mysqli_error());
		if (mysqli_num_rows($result) > 0) 
		{
			$response["clothes"] = array();
			while ($row = mysqli_fetch_array($result)) 
			{
				$clothes = array();
				$clothes["T_ID"] = $row["T_ID"];
				$clothes["T_NAME"] = $row["T_NAME"];
				array_push($response["clothes"], $clothes);
			}

		} 
		else 
		{
			$response["success"] = 0;
			$response["message"] = "No item in the cart";
		}
		
		
			    echo json_encode($response);
		
		

               
	

				
?>