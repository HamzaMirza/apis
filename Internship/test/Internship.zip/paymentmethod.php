<?php require_once("config.php");?>
<?php 
		
		$connection=$_SESSION["CONNECTION"];

		$response = array();
		$response["success"] = 0;
		$response["message"] = "";
		$response["grandTotal"] = 0;
		$response["message"] = "Payment method";
		$result = mysqli_query($connection,"SELECT * FROM `cart` WHERE `ip` ='".$_SESSION["ipAddress"]."'") or die(mysqli_error());
		if (mysqli_num_rows($result) > 0) 
		{
			while ($row = mysqli_fetch_array($result)) 
			{
				$response["grandTotal"] +=$row["total"];
			}
				$response["success"] = 1;
				
		} 
		else 
		{
			$response["success"] = 0;
		}
		
		
			    echo json_encode($response);
		
		

               
	

				
?>