<?php
		session_start();
		$connection = mysqli_connect("localhost", "root", "", "shopping") or die(mysqli_error());
		$_SESSION["CONNECTION"]=$connection;
		$sessionid=0;
		$_SESSION["ipAddress"] = urlencode($_SERVER['REMOTE_ADDR']);
		$Query="SELECT (cart.SessionID) as SessionID FROM `cart` where ip='".$_SESSION["ipAddress"]."'";
		if($Result=mysqli_query($connection,$Query))
		{
			if ($row = mysqli_fetch_array($Result)) 
			{
					$sessionid = $row["SessionID"];
			}
		}
		else
		{
				$Query="SELECT max(cart.SessionID)+1 as SessionID FROM `cart` ";
				$Result=mysqli_query($connection,$Query);
				if ($row = mysqli_fetch_array($Result)) 
				{
					$sessionid = $row["SessionID"];
				}
		}
		
		$_SESSION["sess_id"]=$sessionid;
?>
